package ar.edu.unlam.pb1;

public class Viaje {
	
	private Destino destino;
	private String nombreMascota;
	private int porcentajeDescuento;
	private double precioBruto;
	private double precioNeto;
	
	public Viaje (Destino destino, String nombreMascota, int porcentajeDescuento) {
		this.destino=destino;
		this.nombreMascota=nombreMascota;
		this.porcentajeDescuento=porcentajeDescuento;
		
	}
	
	 
	
	

}
